#!/usr/bin/env python
# -*- coding: utf-8 -*-
# sphinx_gallery_thumbnail_number = 3

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import NullFormatter  # useful for `logit` scale
import matplotlib.ticker as ticker
import matplotlib as mpl
#from scipy.interpolate import spline
from matplotlib import cm
from matplotlib import axes
from matplotlib.font_manager import FontProperties
import pylab as pl
from matplotlib.colors import LinearSegmentedColormap

mpl.style.use('classic')
# Data for plotting
c2data=np.loadtxt('./c2data.dat')
pb=np.loadtxt('./phaseboundary.dat')
mubdata=np.loadtxt('./freezeout/mub.dat')
FOAndro=np.loadtxt('./freezeout/Tandro.dat')
FOI=np.loadtxt('./freezeout/STARFitI.dat')
FOII=np.loadtxt('./freezeout/STARFitII.dat')
# Create figure
fig=plt.figure(figsize=(5, 3.5))
colors = ['#053061', '#134b87', '#327db7', '#6fafd2', '#c7e0ed', '#fbd2bc', '#feab88', '#b71c2c', '#8b0824']  # 深蓝-白-深红
cmap_custom = LinearSegmentedColormap.from_list('mymap', colors)
####################################################################################################
ax2=fig.add_subplot(111)
vd=0.019
vu=0.0285
im=ax2.imshow(c2data.T, cmap=cmap_custom,interpolation='nearest',vmin=vd,vmax=vu,zorder=3,extent=[0, 555, 21, 300], origin='lower', aspect=1.7)
vnorm = mpl.colors.Normalize(vmin=vd, vmax=vu)
plt.rcParams['font.size'] = 7
cbar=plt.colorbar(im,fraction=0.029, pad=0.02,norm=vnorm)
cbar.set_label(r'$c_2$', rotation=0,fontsize=12,labelpad=10)
#ax2.set_aspect(0.8) 
#plt.scatter(643,98,color='red',marker='*',s=40,label=r'CEP-Chiral',zorder=3)
#plt.scatter(910,15.5,color='red',marker='o',s=7,label=r'CEP-LG',zorder=3)
pb,=ax2.plot(pb[:,0],pb[:,1],dashes=[1,0],color='k',linewidth=1.2,alpha=0.6,label=r'Crossover',zorder=3)
star4,=ax2.plot(mubdata,FOI,dashes=[4,1,2,1],color='b',linewidth=1.2,alpha=0.6,label=r'freezeout: STAR Fit I',zorder=4)
star4,=ax2.plot(mubdata,FOII,dashes=[5,2],color='g',linewidth=1.2,alpha=0.6,label=r'freezeout: STAR Fit II',zorder=4)
And,=ax2.plot(mubdata,FOAndro,color='r',linewidth=1.2,alpha=0.6,label=r'freezeout: Andronic et al.',zorder=3)
plt.axis([0.,555.,80.,250.])
ax2.set_xlabel('$\mu_B\,[\mathrm{MeV}]$', fontsize=12, color='black')
ax2.set_ylabel(r'$T\,[\mathrm{MeV}]$', fontsize=12, color='black')
ax2.set_aspect(2.2)
for spine in ax2.spines.values():
    spine.set_zorder(10)
ax2.tick_params(which='both', zorder=10)
#ax2.text(30, 90, 'fRG: QCD assisted LEFT', fontsize=7, color='black')
#ax2.text(30, 60, 'Parity-Doublet Model', fontsize=7, color='black')

#ax1.set_title(r'$R^B_{42}$',loc='right')
for label in ax2.xaxis.get_ticklabels():
    label.set_fontsize(8)
for label in ax2.yaxis.get_ticklabels():
    label.set_fontsize(8)
ax2.legend(loc=0,fontsize=7,frameon=True,shadow=True,handlelength=3.,borderpad=0.5,borderaxespad=1,numpoints=1,scatterpoints=1)
fig.subplots_adjust(top=1., bottom=0.0, left=0.112, right=0.85, hspace=0.1,
                    wspace=0.1)

fig.savefig("phasec2.pdf",dpi=300,transparent=True)
